# Cluster Finder — Meteor Addon 1.21.11

Standalone Meteor addon based on the Cluster Finder behavior extracted from Zinc 1.21.4.

Features preserved:
- Scans loaded chunks for Amethyst Cluster blocks.
- Threshold: 5 clusters.
- Scans loaded chunks on activation and newly loaded chunks.
- Uses a 2-thread scan pool.
- Marks each detected chunk once.
- Renders a chunk marker at Y=64.
- Optional toast notification and sound.
- No Zinc dependency.

Target: Minecraft 1.21.11 + Meteor Client 1.21.11.

Build with:
`./gradlew build`

The compiled jar will be in `build/libs/`.
