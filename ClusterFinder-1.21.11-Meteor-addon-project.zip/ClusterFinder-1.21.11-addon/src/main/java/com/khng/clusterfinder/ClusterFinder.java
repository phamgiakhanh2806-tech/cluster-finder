package com.khng.clusterfinder;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.PositionedSoundInstance;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Box;
import meteordevelopment.orbit.EventHandler;

import java.util.Set;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ClusterFinder extends Module {
    private final SettingGroup sgGeneral = settings.createGroup("General");
    private final SettingGroup sgNotifications = settings.createGroup("Notifications");

    private final Setting<SettingColor> chunkColor = sgGeneral.add(new ColorSetting.Builder()
        .name("chunk-color")
        .defaultValue(new SettingColor(180, 50, 230, 60))
        .build());

    private final Setting<Boolean> showToast = sgNotifications.add(new BoolSetting.Builder()
        .name("show-toast")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> playSound = sgNotifications.add(new BoolSetting.Builder()
        .name("play-sound")
        .defaultValue(true)
        .build());

    private static final int CLUSTER_THRESHOLD = 5;
    private static final int THREAD_POOL_SIZE = 2;

    private final Set<ChunkPos> flaggedChunks = ConcurrentHashMap.newKeySet();
    private final Map<ChunkPos, Long> lastNotificationTimes = new ConcurrentHashMap<>();
    private final Queue<Long> recentNotifications = new ConcurrentLinkedQueue<>();

    private ExecutorService threadPool;
    private volatile boolean active;

    public ClusterFinder() {
        super(ClusterFinderAddon.CATEGORY, "ClusterFinder", "Finds Amethyst Clusters.");
    }

    @Override
    public void onActivate() {
        active = true;
        threadPool = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        flaggedChunks.clear();

        for (Chunk chunk : Utils.chunks()) {
            if (chunk instanceof WorldChunk wc) {
                threadPool.submit(() -> scanChunk(wc));
            }
        }
    }

    @Override
    public void onDeactivate() {
        active = false;
        if (threadPool != null) threadPool.shutdownNow();
    }

    @EventHandler
    private void onChunkLoad(ChunkDataEvent event) {
        if (threadPool != null) threadPool.submit(() -> scanChunk(event.chunk()));
    }

    private void scanChunk(WorldChunk chunk) {
        if (!active || chunk == null) return;

        ChunkPos cpos = chunk.getPos();
        int count = 0;
        int topY = chunk.getBottomY() + chunk.getHeight();

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int y = chunk.getBottomY(); y < topY; y++) {
                    BlockPos pos = new BlockPos(cpos.getStartX() + x, y, cpos.getStartZ() + z);
                    if (chunk.getBlockState(pos).isOf(Blocks.AMETHYST_CLUSTER)) count++;
                }
            }
        }

        if (count >= CLUSTER_THRESHOLD && flaggedChunks.add(cpos)) {
            final int finalCount = count;
            MinecraftClient.getInstance().execute(() -> notifyFound(finalCount));
        }
    }

    private void notifyFound(int count) {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (showToast.get()) {
            mc.getToastManager().add(new ClusterToast(
                new ItemStack(Items.AMETHYST_SHARD),
                Text.of("Cluster Found"),
                Text.of(count + " Amethyst Clusters")
            ));
        }

        if (playSound.get()) {
            mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.5f));
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        Color color = new Color(chunkColor.get());

        for (ChunkPos cp : flaggedChunks) {
            Box box = new Box(
                cp.getStartX(), 64.0, cp.getStartZ(),
                cp.getEndX() + 1, 64.5, cp.getEndZ() + 1
            );

            event.renderer.box(box, color, color, ShapeMode.Both, 0);
        }
    }

    private static class ClusterToast implements Toast {
        private final ItemStack icon;
        private final Text title;
        private final Text description;
        private long startTime = -1L;
        private Visibility visibility = Visibility.SHOW;

        ClusterToast(ItemStack icon, Text title, Text description) {
            this.icon = icon;
            this.title = title;
            this.description = description;
        }

        @Override
        public Visibility getVisibility() {
            return visibility;
        }

        @Override
        public void update(ToastManager manager, long time) {
            if (startTime == -1L) startTime = time;
            if (time - startTime >= 5000L) visibility = Visibility.HIDE;
        }

        @Override
        public void draw(DrawContext context, TextRenderer textRenderer, long time) {
            context.fill(0, 0, 160, 32, 0xAA000000);
            int border = 0xFF9900FF;
            context.fill(0, 0, 160, 1, border);
            context.fill(0, 31, 160, 32, border);
            context.fill(0, 1, 1, 31, border);
            context.fill(159, 1, 160, 31, border);

            if (!icon.isEmpty()) context.drawItem(icon, 8, 8);
            if (title != null) context.drawText(textRenderer, title, 32, 7, 0xFFFF00, false);
            if (description != null) context.drawText(textRenderer, description, 32, 18, 0xFFFFFF, false);
        }
    }
}
