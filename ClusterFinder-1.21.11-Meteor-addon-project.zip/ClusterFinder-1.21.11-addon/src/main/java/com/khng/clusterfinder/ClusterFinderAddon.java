package com.khng.clusterfinder;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class ClusterFinderAddon extends MeteorAddon {
    public static final Category CATEGORY = new Category("Cluster Finder");

    @Override
    public void onInitialize() {
        Modules.get().add(new ClusterFinder());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.khng.clusterfinder";
    }

    @Override
    public String getWebsite() {
        return "";
    }
}
